# Junior School Learning Hub — Grade 7 Annual Automated Quiz Bank (2027)

Organised by learning area, term, strand and sub-strand. Each JSON file contains 30 single-choice questions, four options, a correct option, explanation and difficulty level.

**Source basis:** supplied Grade 7 2027 revised term schemes of work. Calendar-only rows are excluded.

**Review note:** This is a generated annual question-bank draft based on the scheme sub-strands and stated learning outcomes. Review the questions against the learner notes and lesson resources before enabling them for live learner assessment.

**Brand:** Junior School Learning Hub.
