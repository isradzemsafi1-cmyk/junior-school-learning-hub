JUNIOR SCHOOL LEARNING HUB
COMBINED AUTOMATED QUIZ BANK — GRADES 7, 8 AND 9
ACADEMIC YEAR 2027

PACKAGE STRUCTURE
- grade7/  Original Grade 7 annual quiz bank, organised by learning area, term and sub-strand.
- grade8/  Original expanded Grade 8 bank, organised by learning area and term.
- grade9/  Original Grade 9 big bank, organised by learning area and term.
- COMBINED_MANIFEST.json  Counts, source package names and integration notes.

VERIFIED RECORD COUNTS
- Grade 7: 4,050
- Grade 8: 2,640
- Grade 9: 3,600
- Combined: 10,290

IMPORTANT ENGINE INTEGRATION NOTE
The original JSON schemas are preserved, not silently rewritten:
- Grade 7 sample fields: prompt, options, correct_option, explanation, difficulty.
- Grades 8 and 9 sample fields: question, options, correct_index, explanation, difficulty.
The quiz engine therefore needs a grade-aware schema adapter before all three banks are loaded through one parser. This ZIP has NOT been uploaded to GitHub and has NOT been connected to the live website.

QUALITY / RELEASE NOTE
These are working generated banks, not a guarantee that every question is already publication-ready. Review subject accuracy, curriculum alignment, correct answers, explanations and duplicate/near-duplicate questions before enabling them for learners. Grade 8 and Grade 9 manifests also retain their source-specific validation warnings.
