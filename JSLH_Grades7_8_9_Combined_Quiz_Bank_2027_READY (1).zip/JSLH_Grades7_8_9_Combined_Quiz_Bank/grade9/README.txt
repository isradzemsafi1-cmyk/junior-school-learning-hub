JUNIOR SCHOOL LEARNING HUB — GRADE 9 — 2027 BIG QUIZ BANK

Total question records: 3600
Learning areas: 9
Sub-strands: 120
30 questions per listed sub-strand.

Each learning area folder has term_1.json, term_2.json, term_3.json and full_year.json. Each record has four options, correct_index, explanation, difficulty, term, strand, sub_strand and question_id.

Expanded working bank. Each item has four choices, a correct answer index, explanation and difficulty. Because some Grade 9 schemes/frameworks and records were teacher-prepared planning documents, validate detailed subject accuracy and exact official curriculum scope before live learner release. The Grade 9 English/Kiswahili/other remaining-area framework was explicitly marked as a working scaffold; use the exact subject design to verify sub-strand detail.
