JSLH Grade 7-9 2027 Quiz Bank — extracted deployment data

Upload/extract this package at the repository root on branch feature/combined-grade7-9-quiz-bank.
It places data under learner-centre/quiz-bank/data/grade7, grade8 and grade9.
The existing loader JavaScript remains separate and unchanged.
Do not merge to main until browser tests pass.
